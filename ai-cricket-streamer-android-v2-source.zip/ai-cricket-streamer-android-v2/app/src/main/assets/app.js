const $=id=>document.getElementById(id);const toast=m=>{const t=$("toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)};
const defaults={scoreUrl:"https://cricketlivenow.com/match/13LT?layout=layout1&source=layout1-only&f=1&sf=2BD&time=1794198600000"};
try{const saved=JSON.parse(localStorage.getItem("aics-settings")||"{}");$("scoreUrl").value=saved.scoreUrl||defaults.scoreUrl;$("ytKey").value=saved.ytKey||"";$("fbKey").value=saved.fbKey||"";}catch(e){}
function save(){const data={scoreUrl:$("scoreUrl").value.trim(),ytKey:$("ytKey").value,fbKey:$("fbKey").value};localStorage.setItem("aics-settings",JSON.stringify(data));toast("سیٹنگز اسی موبائل میں محفوظ ہو گئیں");}
$("saveUrl").onclick=save;$("saveKeys").onclick=save;
$("openScore").onclick=()=>{const u=$("scoreUrl").value.trim();try{const parsed=new URL(u);if(!["http:","https:"].includes(parsed.protocol))throw 0;save();window.open(parsed.href,"_blank","noopener");}catch(e){toast("درست ویب URL درج کریں");}};
document.querySelectorAll("[data-toggle]").forEach(b=>b.onclick=()=>{const i=$(b.dataset.toggle);i.type=i.type==="password"?"text":"password";b.textContent=i.type==="password"?"دکھائیں":"چھپائیں";});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
